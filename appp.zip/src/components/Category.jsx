import React from "react";
import service from "../Assests/service1.png";
import service2 from "../Assests/service2.png";
import service3 from "../Assests/service3.png";
import image1 from "../Assests/image 27.png";
import image2 from "../Assests/image 28.png";
import image3 from "../Assests/image 29.png";
import image4 from "../Assests/image 30.png";
import image5 from "../Assests/image 31.png";
const Category = () => {
  return (
    <>
      <div className="Category">
        <div className="container CardService">
          <div className="services-heading">
            <h6>Category</h6>
            <h5>We Offer Best Services</h5>
          </div>
          <div className="row">
            <div className="col-md-4">
              <div className="card-section">
                <img src={service} />
                <h6>Streamlined Order Management</h6>
                <p>
                  Simplify your business with Delivery Hero's streamlined order
                  management
                </p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="section2">
                <img src={service2} />
                <h6>Real-Time Inventory Tracking</h6>
                <p>
                  Stay in control with Delivery Hero's real-time inventory
                  tracking.
                </p>
                {/* <span className="rectangle"></span> */}
                {/* <img src={rectangle} /> */}
              </div>
            </div>
            <div className="col-md-4">
              <div className="card-section">
                <img src={service3} />
                <h6>Effortless Shipping Label Generation</h6>
                <p>Simplify shipping labels effortlessly with Delivery Hero.</p>
              </div>
            </div>
          </div>
          <div className="row DeliveryImage">
            <div className="col-md-2 ">
              <img src={image1} />
            </div>
            <div className="col-md-2">
              <img src={image2} />
            </div>
            <div className="col-md-2">
              <img src={image3} />
            </div>
            <div className="col-md-2">
              <img src={image4} />
            </div>
            <div className="col-md-2">
              <img src={image5} />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Category;
