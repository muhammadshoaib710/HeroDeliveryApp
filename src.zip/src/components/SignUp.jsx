import React, { useState } from "react";
import Carousal from "./Carousal";
import { NavLink } from "react-router-dom";

const SignUp = () => {
  const [fname, setFname] = useState("");
  const [Lname, setLname] = useState("");
  const [password, setPassword] = useState("");
  const [useErr, setUseErr] = useState(false);
  const [lastUserErr, setLastUseErr] = useState(false);
  const [passErr, setPassErr] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (fname.length < 3 || Lname.length < 3 || password.length < 6) {
      alert("Type Correct Values");
    } else {
      alert("All Good");
    }
  };
  const InputHandle = (e) => {
    let value = e.target.value;
    if (value.length < 3) {
      setUseErr(true);
    } else {
      setUseErr(false);
    }
    setFname(value);
  };
  const LastNameHandle = (e) => {
    let value = e.target.value;
    if (value.length < 3) {
      setLastUseErr(true);
    } else {
      setLastUseErr(false);
    }
    setLname(value);
  };
  const PasswordHandle = (e) => {
    let value = e.target.value;
    if (value.length < 6) {
      setPassErr(true);
    } else {
      setPassErr(false);
    }
    setPassword(value);
  };
  return (
    <>
      <div className="Login">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <Carousal />
            </div>
            <div className="col-md-6 InputSide">
              <div className="FormHeading">
                <h1>Let's get started</h1>
              </div>
              <form className="FormSection" onSubmit={handleSubmit}>
                <div class="form-row">
                  <div className="stateForm">
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">First Name</label>
                      <input
                        type="text"
                        class="form-control"
                        id="inputEmail4"
                        placeholder="First Name"
                        required
                        onChange={InputHandle}
                      />
                      {useErr ? <span>User Not Valid</span> : " "}
                    </div>
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">Last Name</label>
                      <input
                        type="text"
                        class="form-control"
                        id="inputEmail4"
                        placeholder="Last Name"
                        required
                        onChange={LastNameHandle}
                      />
                      {lastUserErr ? <span>User Not Valid</span> : " "}
                    </div>
                  </div>

                  <div class="form-group   ">
                    <label for="inputEmail4">Email</label>
                    <input
                      type="email"
                      class="form-control"
                      id="inputEmail4"
                      placeholder="Email"
                      required
                    />
                  </div>
                  <div class="form-group ">
                    <label for="inputPassword4">Password</label>
                    <input
                      type="password"
                      class="form-control"
                      id="inputPassword4"
                      placeholder="Password"
                      required
                      onChange={PasswordHandle}
                    />
                    {passErr ? <span>Password Not Valid</span> : " "}
                  </div>
                </div>
                <div class="form-row stateForm">
                  <div class="form-group col-md-6">
                    <label for="inputState">Country of residence</label>
                    <select id="inputState" class="form-control">
                      <option selected>Choose</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="inputState">State</label>
                    <select id="inputState" class="form-control">
                      <option selected>Choose</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                      <option>Pakisan</option>
                    </select>
                  </div>
                </div>
                <div class="form-group ">
                  <label for="inputPassword4">Phone Number</label>
                  <input
                    type="text"
                    class="form-control"
                    id="inputPassword4"
                    placeholder="Phone"
                    required
                  />
                </div>
                <div class="form-group">
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="checkbox"
                      id="gridCheck"
                      required
                    />
                    <label class="form-check-label" for="gridCheck">
                      Check me out
                    </label>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary button1">
                  Sign Up
                </button>
                <div class="divider d-flex align-items-center my-4">
                  <p class="text-center fw-bold mx-3 mb-0 text-muted">OR</p>
                </div>
                <button className="btn btn-primary btn-lg btn-block btn2">
                  <i class="fa-solid fa-g me-2"></i>Continue with Google
                </button>
                <p className="SignUpLink">
                  Already have an Account?
                  <NavLink to="/login">Login</NavLink>
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUp;
