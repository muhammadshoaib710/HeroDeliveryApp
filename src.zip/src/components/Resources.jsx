import React from "react";
import { FaFileAlt } from "react-icons/fa";
import Resource from "../Assests/Resource.jpg";
import { NavLink } from "react-router-dom";
import { Rdata } from "../Rdata";

const Resources = () => {
  return (
    <>
      <div className="Resources">
        <div className="container RowResource">
          <div className="row ">
            <div className="col-md-4 leftResource">
              <h1>
                Everything you need to run and grow your
                <span>multi-channel eCommerce business</span>
              </h1>
              <img src={Resource} />
            </div>
            <div className="col-md-8 RightSides">
              {Rdata.map((data) => {
                return (
                  <div className="col-md-4 RightResource">
                    <span className="svg">{data.head}</span>
                    <h1>{data.title}</h1>
                    <p>{data.description}</p>
                    <NavLink to="/">{data.Link}</NavLink>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Resources;
