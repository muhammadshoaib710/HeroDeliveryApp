export const Sdata = [
  {
    id: 1,
    heading: "30%",
    text: "Top 100 Retailers who ship parcel trust Delivery Hero",
  },
  {
    id: 2,
    heading: "1.5+",
    text: "Billion parcel shipments a year",
  },
  {
    id: 3,
    heading: "8000+",
    text: "Shipping origins globally",
  },
  {
    id: 4,
    heading: "845+",
    text: "Billion in customer revenue supported",
  },
];
